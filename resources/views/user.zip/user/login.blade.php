<?php

$ses_url = session()->get('url_current_for_user_logout');
// echo $ses_url;
$vendor_branch_find = \App\VendorBranch::where('branch_url', $ses_url)->first();
$get_branch_logo = \App\User::find($vendor_branch_find->vendor_id);
?>
<x-admin-header></x-admin-header>

<section class="row flexbox-container">
    <div class="col-12 d-flex align-items-center justify-content-center">
        <div class="col-lg-4 col-md-8 col-10 box-shadow-2 p-0">
            <div class="card border-grey border-lighten-3 m-0">
                <div class="card-header border-0">
                    <div class="card-title text-center">

                        @if (Session::get('branch_user_credentials_not_matched'))
                            <?php
                            session()->forget('branch_user_credentials_not_matched');
                            ?>
                            <div class="alert my-2 alert-danger">
                                <p>{{ 'Invalid Credentials' }}</p>
                            </div>
                        @endif
                    
                        @if ($get_branch_logo->laboratory_logo)
                            <img src="{{ asset('uploads/logo/' . $get_branch_logo->laboratory_logo) }}">
                        @else
                            <h1>{{ $vendor_branch_find->branch_name }}</h1>
                        @endif

                        {{-- <h1 class=" text-center  pt-2"><span>{{ $check_slug_exist->laboratory_name }}</span></h1> --}}
                    </div>
                    @if ($message = Session::get('success'))
                        <div class="text-center alert my-2 alert-danger">
                            <p>{{ $message }}</p>
                        </div>
                    @endif
                    <h6 class="card-subtitle line-on-side text-muted text-center font-small-3 "><span>Login</span></h6>

                </div>
                <div class="card-content">


                    <div class="card-body">

                        {{-- <form class="form-horizontal" method="POST" action="{{ route('vendor_login') }}"  novalidate> --}}
                        <form class="form-horizontal" method="POST" action="{{ route('login_submit') }}" novalidate>
                            @csrf
                            <fieldset class="form-group position-relative has-icon-left">
                                <input type="email" class="form-control  @error('email') is-invalid @enderror "
                                    id="email" name="email" placeholder="Your Email" value="{{ old('email') }}"
                                    required autocomplete="email" autofocus>
                                <div class="form-control-position">
                                    <i class="la la-user"></i>
                                </div>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </fieldset>
                            <fieldset class="form-group position-relative has-icon-left">
                                <input type="password" class="form-control @error('password') is-invalid @enderror "
                                    id="password" placeholder="Enter Password" name="password" required
                                    autocomplete="current-password">
                                <div class="form-control-position">
                                    <i class="la la-key"></i>
                                </div>

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </fieldset>
                            <button type="submit" class="btn btn-outline-info btn-block"><i class="la la-unlock"></i>
                                Login</button>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<x-admin-footer></x-admin-footer>
