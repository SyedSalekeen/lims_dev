@extends('user.layouts.master')
@section('content')

    <div class="row">
        <div class="col-12">
            @if ($message = Session::get('success'))
                <div class="alert my-2 alert-success">
                    <p>{{ $message }}</p>
                </div>
            @endif

            @if (Session::get('branch_user_create'))
                <?php
                session()->forget('branch_user_create');
                ?>
                <div class="alert my-2 alert-success">
                    <p>{{ 'User has been created' }}</p>
                </div>
            @endif
            @if (Session::get('branch_user_update'))
                <?php
                session()->forget('branch_user_update');
                ?>
                <div class="alert my-2 alert-success">
                    <p>{{ 'User has been Updated' }}</p>
                </div>
            @endif

            @if (Session::get('branch_user_delete'))
                <?php
                session()->forget('branch_user_delete');
                ?>
                <div class="alert my-2 alert-danger">
                    <p>{{ 'User has been Deleted' }}</p>
                </div>
            @endif





            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">User Management</h4>
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            <li>
                                <a href="{{ route('branch_user.create') }}" id="add_item" class="btn btn-success">
                                    <i class="ft-plus"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="card-content collapse show">

                    <div class="table-responsive">
                        <table class="table table-striped table-sm">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Url</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($user as $item)
                                    <tr>
                                        <td>{{ $loop->index + 1 }}</td>
                                        <td>{{ $item->first_name . ' ' . $item->last_name }}</td>
                                        <td>{{ $item->email }}</td>
                                        <td>{{ $item->branch->branch_url }}</td>
                                        <td><label class="switch">
                                                <input data-id="{{ $item->id }}" type="checkbox" class="toggle_class"
                                                    data-on="Active" data-off="Inactive"
                                                    {{ $item->status ? 'checked' : '' }}>
                                                <span class="slider round"></span>
                                            </label></td>
                                        <td>

                                            <a class="btn  btn-info btn-sm box-shadow-1"
                                                href="{{ route('branch_user.show', $item->id) }}"><i
                                                    class="ft-eye"></i></a>
                                            @if ($get_permission_edit_user)
                                                <a class="btn btn-primary box-shadow-1 btn-sm"
                                                    href="{{ route('branch_user.edit', $item->id) }}"><i
                                                        class="ft-edit"></i></a>
                                            @endif
                                            @if ($get_permission_delete_user)
                                                <span>
                                                    {!! Form::open(['method' => 'DELETE', 'route' => ['branch_user.destroy', $item->id], 'style' => 'display:inline']) !!}
                                                    {!! Form::submit('🗑', ['class' => 'btn btn-danger btn-sm box-shadow-1', 'onclick' => "return confirm('Are you sure you want to delete?');"]) !!}
                                                    {!! Form::close() !!}
                                                </span>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        {{-- {!! $articles->render() !!} --}}
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
