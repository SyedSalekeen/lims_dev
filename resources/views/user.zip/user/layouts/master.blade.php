
@include('user.components.admin-header')
@include('user.components.admin-navbar')
@include('user.components.admin-sidebar')


<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        @include('user.components.admin-breadcrumb')


        <div class="content-body">
            @yield('content')
        </div>
    </div>
</div>

<div class="sidenav-overlay"></div>
<div class="drag-target"></div>

<!-- BEGIN: Footer-->

<!-- END: Footer-->
@yield('scripts')
@include('user.components.admin-footer')

