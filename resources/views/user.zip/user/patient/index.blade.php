@extends('user.layouts.master')
@section('content')

    <div class="row">
        <div class="col-12">
            @if ($message = Session::get('success'))
                <div class="alert my-2 alert-success">
                    <p>{{ $message }}</p>
                </div>
            @endif

            @if (Session::get('branch_patient_create'))
                <?php
                session()->forget('branch_patient_create');
                ?>
                <div class="alert my-2 alert-success">
                    <p>{{ 'Patient has been created' }}</p>
                </div>
            @endif
            @if (Session::get('branch_patient_updated'))
                <?php
                session()->forget('branch_patient_updated');
                ?>
                <div class="alert my-2 alert-success">
                    <p>{{ 'Patient has been updated' }}</p>
                </div>
            @endif
            @if (Session::get('branch_patient_delete'))
                <?php
                session()->forget('branch_patient_delete');
                ?>
                <div class="alert my-2 alert-success">
                    <p>{{ 'Patient has been delete' }}</p>
                </div>
            @endif
            @if (Session::get('branch_patient_filter_one_field_required'))
            <?php
            session()->forget('branch_patient_filter_one_field_required');
            ?>
            <div class="alert my-2 alert-success">
                <p>{{'One of the two fields is required'}}</p>
            </div>
        @endif

            {!! Form::open(['route' => 'branch_patient_filter', 'method' => 'POST']) !!}
            <div class="form form-horizontal mb-5">
                <div class="form-body">
                    <h4 class="form-section"><i class="ft-user"></i>Filter Patient</h4>
                    <div class="form-group row">
                        {{-- <label class="col-md-3 label-control" for="projectinput4">Year</label> --}}
                        <div class="form-group row">

                            <div class="col-md-6 mx-auto">
                                {{-- <input type="text" name="patient_name"> --}}
                                {!! Form::text('patient_name', null, ['placeholder' => 'Patient Name', 'class' => 'form-control']) !!}

                            </div>
                            <div class="col-md-6 mx-auto">
                                {!! Form::text('patient_mr', null, ['placeholder' => 'Patient MR Number', 'class' => 'form-control']) !!}
                            </div>
                        </div>
                    </div>

                    {{-- <label class="col-md-3 label-control" for="projectinput4">Branch</label> --}}





                    {{-- <label class="col-md-3 label-control" for="projectinput4">Year</label> --}}


                    <div class="col-xs-12 col-sm-12 col-md-12 text-center filter_button">
                        <button type="submit" class="btn btn-success float-right box-shadow-1 mt-1 mb-1"><i
                                class="ft-check "></i> Filter</button>
                    </div>
                </div>
                {!! Form::close() !!}
            </div>




            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Patient Management</h4>
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            <li>
                                <a href="{{ route('branch_patient.create') }}" id="add_item" class="btn btn-success">
                                    <i class="ft-plus"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="card-content collapse show">

                    <div class="table-responsive">
                        <table class="table table-striped table-sm">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Name</th>
                                    <th>MR NUMBER</th>
                                    {{-- <th>Url</th> --}}
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($get_patients as $item)
                                    <tr>
                                        <td>{{ $loop->index + 1 }}</td>
                                        <td>{{ $item->first_name . ' ' . $item->last_name }}</td>
                                        <td>{{ $item->email }}</td>
                                        {{-- <td>{{ $item->branch->branch_url }}</td> --}}
                                        {{-- <td><label class="switch">
                                                <input data-id="{{ $item->id }}" type="checkbox" class="toggle_class"
                                                    data-on="Active" data-off="Inactive"
                                                    {{ $item->status ? 'checked' : '' }}>
                                                <span class="slider round"></span>
                                            </label></td> --}}
                                        <td>
                                            <a class="btn  btn-info btn-sm box-shadow-1"
                                                href="{{ route('branch_patient.show', $item->id) }}"><i
                                                    class="ft-eye"></i></a>
                                            @if ($get_permission_edit_patient)
                                                <a class="btn btn-primary box-shadow-1 btn-sm"
                                                    href="{{ route('branch_patient.edit', $item->id) }}"><i
                                                        class="ft-edit"></i></a>
                                            @endif
                                            @if ($get_permission_delete_patient)
                                                <span>
                                                    {!! Form::open(['method' => 'DELETE', 'route' => ['branch_patient.destroy', $item->id], 'style' => 'display:inline']) !!}
                                                    {!! Form::submit('🗑', ['class' => 'btn btn-danger btn-sm box-shadow-1', 'onclick' => "return confirm('Are you sure you want to delete?');"]) !!}
                                                    {!! Form::close() !!}
                                                </span>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        {{-- {!! $articles->render() !!} --}}
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
