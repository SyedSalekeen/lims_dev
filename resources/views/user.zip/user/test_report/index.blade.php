@extends('user.layouts.master')
@section('content')

    <div class="row">
        <div class="col-12">
            @if ($message = Session::get('success'))
                <div class="alert my-2 alert-success">
                    <p>{{ $message }}</p>
                </div>
            @endif

            @if ($message = Session::get('error'))
                <div class="alert my-2 alert-danger">
                    <p>{{ $message }}</p>
                </div>
            @endif

            @if (Session::get('vendor_test_add'))
                <?php
                session()->forget('vendor_test_add');
                ?>
                <div class="alert my-2 alert-success">
                    <p>{{ 'Test has been created' }}</p>
                </div>
            @endif
            @if (Session::get('vendor_test_updated'))
                <?php
                session()->forget('vendor_test_updated');
                ?>
                <div class="alert my-2 alert-success">
                    <p>{{ 'Test has been updated'}}</p>
                </div>
            @endif
            @if (Session::get('vendor_test_deleted'))
                <?php
                session()->forget('vendor_test_deleted');
                ?>
                <div class="alert my-2 alert-success">
                    <p>{{ 'Test has been deleted' }}</p>
                </div>
            @endif


            <div class="card">
                <input type="hidden" value="{{ csrf_token() }}" name="_token" id="token">
                <div class="card-header">
                    <h4 class="card-title">Report Listening</h4>
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                       
                    </div>
                </div>
                <div class="card-content collapse show">

                    <div class="table-responsive">
                        <table class="table table-striped table-sm">
                            <thead>
                                <tr>
                                    <th> Sr #</th>
                                    <th>Patient MR Number</th>
                                    <th>Test Issue Date</th>
                                 
                                    <th>Reports</th>
                                    <th>Actions</th>

                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($TestReport as $value)
                                    <tr role="row">
                                        <td>{{ $loop->index+1 }}</td>
                                        <td>{{ $value->patient_id }}</td>
                                        <td>{{ date('d-m-Y', strtotime($value->created_at))}}</td>
                                       
                                        <td >

                                                    <a target="_blank" class="btn  btn-success btn-sm box-shadow-1 mr-1"
                                                href="{{ route('branch_patient_report.show', $value->id) }}"><i
                                                    class="ft-eye"></i> Report</a>
                                        </td>
                                        <td class="d-flex border-0">
                                            {!! Form::open(['method' => 'DELETE', 'route' => ['branch_patient_report.destroy', $value->id], 'style' => 'display:inline']) !!}
                                            {!! Form::submit('🗑', ['class' => 'btn btn-danger btn-sm box-shadow-1', 'onclick' => "return confirm('Are you sure you want to delete?');"]) !!}
                                            {!! Form::close() !!}
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script>

    </script>
@endsection
