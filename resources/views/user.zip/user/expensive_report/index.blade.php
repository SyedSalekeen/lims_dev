@extends('user.layouts.master')
@section('content')

    <div class="row">
        <div class="col-12">
            @if ($message = Session::get('success'))
                <div class="alert my-2 alert-success">
                    <p>{{ $message }}</p>
                </div>
            @endif

            @if ($message = Session::get('error'))
                <div class="alert my-2 alert-danger">
                    <p>{{ $message }}</p>
                </div>
            @endif

            @if (Session::get('expensive_report_store'))
                <?php
                session()->forget('expensive_report_store');
                ?>
                <div class="alert my-2 alert-success">
                    <p>{{ 'Expensive Report has been added' }}</p>
                </div>
            @endif

            @if (Session::get('expensive_report_updated'))
                <?php
                session()->forget('expensive_report_updated');
                ?>
                <div class="alert my-2 alert-success">
                    <p>{{ 'Expensive Report has been updated' }}</p>
                </div>
            @endif



            {!! Form::open(['route' => 'branch-expensive-report.filterReports', 'method' => 'POST']) !!}
            <div class="form form-horizontal mb-5">
                <div class="form-body">
                    <h4 class="form-section"><i class="ft-user"></i>Filter Expensive Report</h4>
                    <div class="form-group row">
                        {{-- <label class="col-md-3 label-control" for="projectinput4">Year</label> --}}
                        <div class="col-md-2 mx-auto">
                            <select class="form-select cstm-slect" name="day" aria-label="Default select example">
                                <option selected disabled>Select Date</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                                <option value="1">11</option>
                                <option value="2">12</option>
                                <option value="3">13</option>
                                <option value="4">14</option>
                                <option value="5">15</option>
                                <option value="6">16</option>
                                <option value="7">17</option>
                                <option value="8">18</option>
                                <option value="9">19</option>
                                <option value="10">20</option>
                                <option value="1">21</option>
                                <option value="2">22</option>
                                <option value="3">23</option>
                                <option value="4">24</option>
                                <option value="5">25</option>
                                <option value="6">26</option>
                                <option value="7">27</option>
                                <option value="8">28</option>
                                <option value="9">29</option>
                                <option value="10">30</option>
                                <option value="10">31</option>
                            </select>
                        </div>
                        <div class="col-md-2 mx-auto">
                            <select class="form-select cstm-slect" name="month" aria-label="Default select example">
                                <option selected disabled>Select Month</option>
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>

                            </select>
                        </div>
                        <div class="col-md-2 mx-auto">
                            <select class="form-select cstm-slect" name="year" aria-label="Default select example">
                                <option selected disabled>Select Year</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                                <option value="2026">2026</option>
                                <option value="2027">2027</option>
                                <option value="2028">2028</option>
                                <option value="2029">2029</option>
                                <option value="2030">2030</option>
                            </select>
                        </div>

                    </div>

                    {{-- <label class="col-md-3 label-control" for="projectinput4">Branch</label> --}}





                    {{-- <label class="col-md-3 label-control" for="projectinput4">Year</label> --}}


                    <div class="col-xs-12 col-sm-12 col-md-12 text-center filter_button">
                        <button type="submit" class="btn btn-success float-right box-shadow-1 mt-1 mb-1"><i
                                class="ft-check "></i> Filter</button>
                    </div>
                </div>
                {!! Form::close() !!}
            </div>









            <div class="card mt-5">
                <input type="hidden" value="{{ csrf_token() }}" name="_token" id="token">
                <div class="card-header">
                    <h4 class="card-title">Expensive Reports</h4>
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            <li>
                                <a href="{{ route('branch_expensive_report.create') }}" id="add_item" class="btn btn-success">
                                    <i class="ft-plus"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>


















                <div class="card-content collapse show">

                    <div class="table-responsive">
                        <table class="table table-striped table-sm">
                            <thead>
                                <tr>
                                    <th> Sr #</th>
                                    <th>Name</th>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Description</th>
                                    <th>Actions</th>
                                    {{-- <th>Phone</th>
                                    <th>Garge</th>
                                    <th>Action</th> --}}
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($get_expensive_reports as $value)
                                    <tr role="row">
                                        <td>{{ $loop->index + 1 }}</td>
                                        <td>{{ $value->expensive_name }}</td>
                                        <td>{{ date('F d, Y', strtotime($value->created_at))}}</td>
                                        <td>{{ $value->expensive_amount }}</td>
                                        <td>{{ $value->expensive_description }}</td>
                                        <td class="d-flex border-0">
                                            @if($get_permission_edit_expensive_report)
                                            <a class="btn btn-primary box-shadow-1 btn-sm mr-1"
                                                href="{{ route('branch_expensive_report.edit', $value->id) }}"><i
                                                    class="ft-edit"></i></a>
                                                    @endif
                                                    @if($get_permission_delete_expensive_report)
                                            {!! Form::open(['method' => 'DELETE', 'route' => ['branch_expensive_report.destroy', $value->id], 'style' => 'display:inline']) !!}
                                            {!! Form::submit('🗑', ['class' => 'btn btn-danger btn-sm box-shadow-1', 'onclick' => "return confirm('Are you sure you want to delete?');"]) !!}
                                            {!! Form::close() !!}
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script>

    </script>
@endsection
