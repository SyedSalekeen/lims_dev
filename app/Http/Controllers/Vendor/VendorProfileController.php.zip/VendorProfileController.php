<?php

namespace App\Http\Controllers\Vendor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Hash;
use App\VendorBranch;
use Spatie\Permission\Models\Role;
use App\Vendor\RolePermission;
use Spatie\Permission\Models\Permission;


class VendorProfileController extends Controller
{
    // public function edit()
    // {
    //     $user = User::find(auth()->id());
    //     return view('vendor.profile', get_defined_vars());
    // }


    public function edit(Request $request)
    {
        return redirect()->route('requestpath', ['slug' => Auth()->user()->laboratory_slug, 'requestpath' => $request->path()]);
    }
    public function create_slug_new()
    {
        return  $user = User::find(auth()->id());
        return view('vendor.profile', get_defined_vars());
    }

    public function requestpath(Request $request)
    {

        $myString = $request->path();
        if (strpos($myString, 'branch_create') !== false) {
            return view('vendor.branch.create');
        }
        if (strpos($myString, 'branch') !== false) {
            $shop = VendorBranch::where('delete_status', '0')->where('vendor_id',auth()->id())->orderBy('id', 'DESC')->paginate(5);
            // $branch_name =
            return view('vendor.branch.index', compact('shop'))
                ->with('i', ($request->input('page', 1) - 1) * 5);
        }
        if (strpos($myString, 'vendor_user_create') !== false) {
            $get_vendor_branch = VendorBranch::where('vendor_id', auth()->id())->where('delete_status', '0')->where('status', '1')->get();
            $get_vendor_branch_role = Role::all();

            return view('vendor.user.create', get_defined_vars());
        }

        if (strpos($myString, 'vendor_user') !== false) {

            $user = User::where('vendor_id', auth()->id())->where('delete_status', '0')->get();
            return view('vendor.user.index', get_defined_vars());
        }

        if (strpos($myString, 'role_permission_create') !== false) {
            $permission = Permission::get();
            $get_vendor_branch = VendorBranch::where('vendor_id', auth()->id())->where('delete_status', '0')->where('status', '1')->get();
            $get_vendor_branch_role = Role::all();

            return view('vendor.role_permission.create', get_defined_vars());
        }
        if (strpos($myString, 'role_permission') !== false) {
            $getPermissions  = RolePermission::where('vendor_id', auth()->id())->get();

            return view('vendor.role_permission.index', get_defined_vars());
        }
        if (strpos($myString, 'vendor_dashboard') !== false) {
            return view('admin.dashboard.index');
        }

        $user = User::find(auth()->id());
        return view('vendor.profile', get_defined_vars());
    }



    public function vendor_profile_update(Request $request, $id)
    {
        // dd($id);
        // dd($request->all());
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'contact_number' => 'required',
            'country' => 'required',
            'city' => 'required',
            'state' => 'required',
            'address' => 'required',
            'profile_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:7168|sometimes',
        ]);
        $update_vendor = User::find($id);
        // dd($update_vendor);
        $update_vendor->first_name = $request->first_name;
        $update_vendor->last_name = $request->last_name;

        if ($request->password) {
            $update_vendor->password = Hash::make($request->password);
        }
        if ($request->hasfile('profile_image')) {
            $file = $request->file('profile_image');
            $extension = $file->getClientOriginalExtension();
            $filename = uniqid() . "." . $extension;
            $file->move(public_path('uploads/profile/'), $filename);
            $update_vendor->profile_image = $filename;
        }

        $update_vendor->contact_number = $request->contact_number;
        $update_vendor->city = $request->city;
        $update_vendor->state = $request->state;
        $update_vendor->country = $request->country;
        $update_vendor->address = $request->address;
        $update_vendor->save();
        return redirect(Auth()->user()->laboratory_url)->with('success', 'User updated successfully');
    }
}
