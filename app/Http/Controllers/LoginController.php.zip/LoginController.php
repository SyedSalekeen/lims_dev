<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\URL;
use function GuzzleHttp\Promise\all;

class LoginController extends Controller
{

    public function dashboard_view()
    {
        return view('admin.layouts.master');
    }
    // public function user_login_view($slug)
    // {
    //     // return $slug;
    //     // $_ENV['APP_URL'] = $slug;

    //     session()->put('slug', $slug);
    //     $check_slug_exist = User::where('laboratory_slug', $slug)->first();
    //     // return $check_slug_exist;
    //     if ($check_slug_exist) {
    //         return view('users_login.login', get_defined_vars());
    //     }
    // }

    public function user_login_view(Request $request, $slug)
    {

        if (session()->get('userlogin')) {
            $data = User::orderBy('id', 'DESC')->where('delete_status', '0')->paginate(5);
            return view('admin.dashboard.index');
            return view('admin.user.index', compact('data'))
                ->with('i', ($request->input('page', 1) - 1) * 5);
        }
        session()->put('slug', $slug);
        $check_slug_exist = User::where('laboratory_slug', $slug)->first();
        // return $check_slug_exist;
        if ($check_slug_exist) {

            return view('users_login.login', get_defined_vars());
        } else {
            return back();
        }
    }
    public function user_login_submit(Request $request)
    {
        $check_status = User::where('email', $request->email)->first();
        if ($check_status->status == "1") {
            $credentials = $request->only('email', 'password');
            if (Auth::attempt($credentials)) {
                session()->put('userlogin', true);


                return redirect(Auth()->user()->laboratory_url);
            } else {
                session()->forget('userlogin');
                return back();
            }
        } else{
            return back()
            ->with('success', 'Your laboratory is blocked by admin');
        }
    }



    public function user_logout()
    {
        $sessionCode = session()->get('slug');
        // dd($sessionCode);
        Session::flush();
        Auth::logout();

        return redirect($sessionCode);
    }

    // public function vendor_login(Request $request)
    // {
    //     // dd($request->all());
    //     // $currentURL = URL::current();
    //     // dd($currentURL);
    //     $finding_user_type = User::where('email', $request->email)->first();
    //     $credentials = [
    //         'email' => $request['email'],
    //         'password' => $request['password'],
    //     ];
    //     if ($finding_user_type->type == "2") {
    //         if (Auth::attempt($credentials)) {
    //             return redirect()->route('dashboard_view');
    //         }
    //     }
    // }
}
